package com.pavelsikun.seekbarpreference;

public interface ChangeValueListener {
    boolean onChange(int value);
}
