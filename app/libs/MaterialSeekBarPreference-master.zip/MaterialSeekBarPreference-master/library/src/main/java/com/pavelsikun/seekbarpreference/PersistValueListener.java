package com.pavelsikun.seekbarpreference;

/**
 * Created by Pavel Sikun on 21.05.16.
 */

public interface PersistValueListener {
    boolean persistInt(int value);
}